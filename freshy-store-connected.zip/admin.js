const {createClient}=window.supabase||{};let sb, editing=null;
function init(){if(!window.SUPABASE_URL||window.SUPABASE_URL.startsWith('YOUR_'))return;sb=createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY);check();}
async function check(){const {data:{session}}=await sb.auth.getSession();if(session){showApp();loadAll()}else showLogin();}
function showLogin(){loginBox.hidden=false;adminApp.hidden=true} function showApp(){loginBox.hidden=true;adminApp.hidden=false}
loginForm.onsubmit=async e=>{e.preventDefault();const {error}=await sb.auth.signInWithPassword({email:email.value,password:password.value});loginMsg.textContent=error?error.message:'';if(!error){showApp();loadAll()}};
async function logout(){await sb.auth.signOut();showLogin()}
async function loadAll(){loadProducts();loadOrders()}
async function loadProducts(){const {data,error}=await sb.from('products').select('*').order('created_at',{ascending:false});productAdmin.innerHTML=error?error.message:(data||[]).map(p=>`<div class="admin-item"><div><b>${esc(p.name)}</b> — ₹${Number(p.price).toFixed(2)}<br><small>${p.active?'Visible':'Hidden'}</small></div><div><button onclick="toggleActive('${p.id}',${!p.active})">${p.active?'Hide':'Show'}</button> <button onclick='editProduct(${JSON.stringify(p)})'>Edit</button> <button onclick="deleteProduct('${p.id}')">Delete</button></div></div>`).join('')||'<p>No products.</p>'}
productForm.onsubmit=async e=>{e.preventDefault();const row={name:pname.value.trim(),price:Number(pprice.value),image_url:pimage.value.trim()||null,description:pdesc.value.trim()};let r=editing?await sb.from('products').update(row).eq('id',editing):await sb.from('products').insert(row);if(r.error)alert(r.error.message);editing=null;productForm.reset();productForm.querySelector('button').textContent='Add Product';loadProducts()}
function editProduct(p){editing=p.id;pname.value=p.name;pprice.value=p.price;pimage.value=p.image_url||'';pdesc.value=p.description||'';productForm.querySelector('button').textContent='Save Changes'}
async function toggleActive(id,v){await sb.from('products').update({active:v}).eq('id',id);loadProducts()}
async function deleteProduct(id){if(confirm('Delete this product?')){await sb.from('products').delete().eq('id',id);loadProducts()}}
async function loadOrders(){const {data,error}=await sb.from('orders').select('*').order('created_at',{ascending:false});orders.innerHTML=error?error.message:(data||[]).map(o=>`<div class="order"><b>${esc(o.customer_name)}</b> — ₹${Number(o.total).toFixed(2)}<br>📞 ${esc(o.phone)}<br>📍 ${esc(o.address)}<br><small>${new Date(o.created_at).toLocaleString()} · ${esc(o.status)}</small><br><button onclick="setStatus('${o.id}','Confirmed')">Confirm</button> <button onclick="setStatus('${o.id}','Shipped')">Shipped</button> <button onclick="setStatus('${o.id}','Delivered')">Delivered</button></div>`).join('')||'<p>No orders.</p>'}
async function setStatus(id,status){await sb.from('orders').update({status}).eq('id',id);loadOrders()}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
init();
