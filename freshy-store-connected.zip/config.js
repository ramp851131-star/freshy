window.SUPABASE_URL = "https://jleeiaktplcsjpgmzopm.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_XGiJfYclvwJALSxtb-knpQ_QfUasbhv";
