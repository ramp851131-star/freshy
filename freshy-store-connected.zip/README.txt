FRESHY STORE

1. Create a Supabase project.
2. In config.js replace YOUR_SUPABASE_URL and YOUR_SUPABASE_ANON_KEY.
3. Create an admin user in Supabase Authentication.
4. IMPORTANT: Before publishing, apply the secure RLS policies supplied in the setup instructions.
5. Upload all files to GitHub.
6. Connect the GitHub repository to Netlify.

The site has:
- Customer product listing
- Cart
- Cash-on-delivery checkout
- Private admin login
- Product management
- Order management

Do not put your Supabase service-role key in config.js. Only the public anon key belongs in the browser.
